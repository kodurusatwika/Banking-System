import java.io.*;
import java.util.*;

public class BankingSystem {

    static Map<String, User> users = new LinkedHashMap<>();
    static final String DATA_FILE = "bank_data.txt";
    static Scanner sc = new Scanner(System.in);
    static User currentUser = null;

    public static void main(String[] args) {
        loadData();
        System.out.println("========= Welcome to Banking System =========");

        while (true) {
            System.out.println("\n1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> registerUser();
                case "2" -> loginUser();
                case "3" -> {
                    saveData();
                    System.out.println("Thank you!");
                    System.exit(0);
                }
                default -> System.out.println("Invalid option, try again!");
            }
        }
    }

    static void registerUser() {
        System.out.print("Enter new username: ");
        String uname = sc.nextLine().trim();
        if (users.containsKey(uname)) {
            System.out.println("Username already exists!");
            return;
        }
        System.out.print("Enter password: ");
        String pwd = sc.nextLine().trim();
        users.put(uname, new User(uname, pwd));
        System.out.println("Registration successful");
        saveData();
    }

    static void loginUser() {
        System.out.print("Enter username: ");
        String uname = sc.nextLine().trim();
        System.out.print("Enter password: ");
        String pwd = sc.nextLine().trim();

        if (users.containsKey(uname) && users.get(uname).password.equals(pwd)) {
            currentUser = users.get(uname);
            System.out.println("\nWelcome back, " + currentUser.username + "!");
            userMenu();
        } else {
            System.out.println("Invalid credentials");
        }
    }

    static void userMenu() {
        while (true) {
            System.out.println("\n1. View Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("7. Logout");
            System.out.print("Choose: ");
            String choice = sc.nextLine();

            try {
                switch (choice) {
                    case "1" -> viewBalance();
                    case "2" -> depositMoney();
                    case "3" -> withdrawMoney();
                    case "4" -> transferMoney();
                    case "7" -> {
                        currentUser = null;
                        System.out.println("Logged out successfully");
                        saveData();
                        return;
                    }
                    default -> System.out.println("Invalid option, try again!");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    static void viewBalance() {
        System.out.printf("Your current balance: ₹%.2f%n", currentUser.balance);
    }

    static void depositMoney() {
        System.out.print("Enter amount to deposit: ");
        double amt = Double.parseDouble(sc.nextLine());
        if (amt <= 0) {
            System.out.println("Amount must be positive.");
            return;
        }
        currentUser.deposit(amt);
        System.out.printf("₹%.2f deposited successfully!%n", amt);
        saveData();
    }

    static void withdrawMoney() throws Exception {
        System.out.print("Enter amount to withdraw: ");
        double amt = Double.parseDouble(sc.nextLine());
        currentUser.withdraw(amt);
        System.out.printf("₹%.2f withdrawn successfully!%n", amt);
        saveData();
    }

    static void transferMoney() throws Exception {
        System.out.print("Enter receiver username: ");
        String receiverName = sc.nextLine().trim();
        if (!users.containsKey(receiverName)) {
            System.out.println("Receiver not found!");
            return;
        }
        System.out.print("Enter amount to transfer: ");
        double amt = Double.parseDouble(sc.nextLine());
        currentUser.transfer(users.get(receiverName), amt);
        System.out.printf("₹%.2f transferred to %s%n", amt, receiverName);
        saveData();
    }

    static void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(users);
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    static void loadData() {
        File f = new File(DATA_FILE);
        if (!f.exists()) return;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            users = (Map<String, User>) ois.readObject();
        } catch (Exception e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }
}
