import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

class User implements Serializable {
    String username;
    String password;
    double balance;
    List<String> transactions = new ArrayList<>();

    User(String username, String password) {
        this.username = username;
        this.password = password;
        this.balance = 0.0;
    }

    void deposit(double amount) {
        balance += amount;
        transactions.add("Deposited ₹" + amount + " at " + LocalDateTime.now());
    }

    void withdraw(double amount) throws Exception {
        if (amount <= 0) throw new Exception("Invalid amount.");
        if (amount > balance) throw new Exception("Insufficient balance.");
        balance -= amount;
        transactions.add("Withdrew ₹" + amount + " at " + LocalDateTime.now());
    }

    void transfer(User receiver, double amount) throws Exception {
        if (amount <= 0) throw new Exception("Invalid amount.");
        if (amount > balance) throw new Exception("Insufficient balance.");
        balance -= amount;
        receiver.balance += amount;
        transactions.add("Transferred ₹" + amount + " to " + receiver.username + " at " + LocalDateTime.now());
        receiver.transactions.add("Received ₹" + amount + " from " + username + " at " + LocalDateTime.now());
    }

}
